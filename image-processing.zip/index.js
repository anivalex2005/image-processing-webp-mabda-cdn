// index.js

'use strict';

const animated = require('animated-gif-detector'),
      fetch = require('node-fetch'),
      sharp = require('sharp');

exports.handler = async (event, context, callback) => {
    try {
        const allowedContentTypes = ['image/gif', 'image/jpeg', 'image/png'];
        const request = event.Records[0].cf.request;
        let response = event.Records[0].cf.response;
        const responseContentType = response.headers['content-type'][0].value;

        if ('200' !== response.status 
          || !allowedContentTypes.includes(responseContentType) 
          || ('image/gif' === responseContentType && animated(response.body))
        ) {
            return callback(null, response);
        }

        let newContentType = null;
        const originalImage = await fetch(`https://${request.headers.host[0].value}${request.uri}`);
        const originalImageBuffer = await originalImage.buffer();
        const sharpImage = sharp(originalImageBuffer);

        if ('image/gif' === responseContentType) {
            sharpImage.png();
            newContentType = [{ value: 'image/png' }];
        }

        if (request.headers['accept'] && request.headers['accept'][0].value.match('image/webp')) {
            sharpImage.webp();
            newContentType = [{ key: 'Content-Type', value: 'image/webp' }];
        }

        const sharpImageBuffer = await sharpImage.toBuffer();
        const responseBody = sharpImageBuffer.toString('base64');

        if (1330000 < Buffer.byteLength(responseBody)) {
            return callback(null, response);
        }

        if (newContentType) {
            response.headers['content-type'] = newContentType;
        }

        response.body = responseBody;
        response.bodyEncoding = 'base64';

        callback(null, response);
    } catch (error) {
        console.log(error);
    }
};